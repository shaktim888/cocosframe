//// prefix begin lsc
//#ifndef GCUnion
//#define GCUnion lua_GCUnion
//#endif
//#ifndef LoadS
//#define LoadS lua_LoadS
//#endif
//#ifndef luaL_Buffer
//#define luaL_Buffer lua_luaL_Buffer
//#endif
//#ifndef luaL_Stream
//#define luaL_Stream lua_luaL_Stream
//#endif
//#ifndef cD
//#define cD lua_cD
//#endif
//#ifndef Mbuffer
//#define Mbuffer lua_Mbuffer
//#endif
//#ifndef BinOpr
//#define BinOpr lua_BinOpr
//#endif
//#ifndef LX
//#define LX lua_LX
//#endif
//#ifndef UBox
//#define UBox lua_UBox
//#endif
//#ifndef GMatchState
//#define GMatchState lua_GMatchState
//#endif
//#ifndef MatchState
//#define MatchState lua_MatchState
//#endif
//#ifndef UUdata
//#define UUdata lua_UUdata
//#endif
//#ifndef Vardesc
//#define Vardesc lua_Vardesc
//#endif
//#ifndef LexState
//#define LexState lua_LexState
//#endif
//#ifndef Ftypes
//#define Ftypes lua_Ftypes
//#endif
//#ifndef lua_longjmp
//#define lua_longjmp lua_lua_longjmp
//#endif
//#ifndef Zio
//#define Zio lua_Zio
//#endif
//#ifndef BlockCnt
//#define BlockCnt lua_BlockCnt
//#endif
//#ifndef CallS
//#define CallS lua_CallS
//#endif
//#ifndef lua_TValue
//#define lua_TValue lua_lua_TValue
//#endif
//#ifndef Udata
//#define Udata lua_Udata
//#endif
//#ifndef OpMode
//#define OpMode lua_OpMode
//#endif
//#ifndef Labellist
//#define Labellist lua_Labellist
//#endif
//#ifndef Table
//#define Table lua_Table
//#endif
//#ifndef CClosure
//#define CClosure lua_CClosure
//#endif
//#ifndef LG
//#define LG lua_LG
//#endif
//#ifndef TKey
//#define TKey lua_TKey
//#endif
//#ifndef ConsControl
//#define ConsControl lua_ConsControl
//#endif
//#ifndef CallInfo
//#define CallInfo lua_CallInfo
//#endif
//#ifndef SParser
//#define SParser lua_SParser
//#endif
//#ifndef TString
//#define TString lua_TString
//#endif
//#ifndef Upvaldesc
//#define Upvaldesc lua_Upvaldesc
//#endif
//#ifndef LClosure
//#define LClosure lua_LClosure
//#endif
//#ifndef Token
//#define Token lua_Token
//#endif
//#ifndef global_State
//#define global_State lua_global_State
//#endif
//#ifndef stringtable
//#define stringtable lua_stringtable
//#endif
//#ifndef lua_State
//#define lua_State lua_lua_State
//#endif
//#ifndef luaL_Reg
//#define luaL_Reg lua_luaL_Reg
//#endif
//#ifndef LoadF
//#define LoadF lua_LoadF
//#endif
//#ifndef UTString
//#define UTString lua_UTString
//#endif
//#ifndef Header
//#define Header lua_Header
//#endif
//#ifndef RESERVED
//#define RESERVED lua_RESERVED
//#endif
//#ifndef Dyndata
//#define Dyndata lua_Dyndata
//#endif
//#ifndef UnOpr
//#define UnOpr lua_UnOpr
//#endif
//#ifndef LocVar
//#define LocVar lua_LocVar
//#endif
//#ifndef Proto
//#define Proto lua_Proto
//#endif
//#ifndef Labeldesc
//#define Labeldesc lua_Labeldesc
//#endif
//#ifndef KOption
//#define KOption lua_KOption
//#endif
//#ifndef FuncState
//#define FuncState lua_FuncState
//#endif
//#ifndef expdesc
//#define expdesc lua_expdesc
//#endif
//#ifndef GCObject
//#define GCObject lua_GCObject
//#endif
//#ifndef UpVal
//#define UpVal lua_UpVal
//#endif
//#ifndef LHS_assign
//#define LHS_assign lua_LHS_assign
//#endif
//#ifndef Closure
//#define Closure lua_Closure
//#endif
//#ifndef OpArgMask
//#define OpArgMask lua_OpArgMask
//#endif
//#ifndef init_exp
//#define init_exp lua_init_exp
//#endif
//#ifndef luaB_setmetatable
//#define luaB_setmetatable lua_luaB_setmetatable
//#endif
//#ifndef luaT_callorderTM
//#define luaT_callorderTM lua_luaT_callorderTM
//#endif
//#ifndef loadfunc
//#define loadfunc lua_loadfunc
//#endif
//#ifndef luaL_loadfilex
//#define luaL_loadfilex lua_luaL_loadfilex
//#endif
//#ifndef newfile
//#define newfile lua_newfile
//#endif
//#ifndef skipcomment
//#define skipcomment lua_skipcomment
//#endif
//#ifndef funcnamefromcode
//#define funcnamefromcode lua_funcnamefromcode
//#endif
//#ifndef luaF_close
//#define luaF_close lua_luaF_close
//#endif
//#ifndef luaT_gettm
//#define luaT_gettm lua_luaT_gettm
//#endif
//#ifndef addk
//#define addk lua_addk
//#endif
//#ifndef luaO_pushfstring
//#define luaO_pushfstring lua_luaO_pushfstring
//#endif
//#ifndef luaF_initupvals
//#define luaF_initupvals lua_luaF_initupvals
//#endif
//#ifndef luaL_ref
//#define luaL_ref lua_luaL_ref
//#endif
//#ifndef checkHeader
//#define checkHeader lua_checkHeader
//#endif
//#ifndef luaF_newLclosure
//#define luaF_newLclosure lua_luaF_newLclosure
//#endif
//#ifndef luaL_optinteger
//#define luaL_optinteger lua_luaL_optinteger
//#endif
//#ifndef setpause
//#define setpause lua_setpause
//#endif
//#ifndef lua_setglobal
//#define lua_setglobal lua_lua_setglobal
//#endif
//#ifndef luaG_addinfo
//#define luaG_addinfo lua_luaG_addinfo
//#endif
//#ifndef localstat
//#define localstat lua_localstat
//#endif
//#ifndef computesizes
//#define computesizes lua_computesizes
//#endif
//#ifndef newlabelentry
//#define newlabelentry lua_newlabelentry
//#endif
//#ifndef luaD_protectedparser
//#define luaD_protectedparser lua_luaD_protectedparser
//#endif
//#ifndef luaB_getmetatable
//#define luaB_getmetatable lua_luaB_getmetatable
//#endif
//#ifndef primaryexp
//#define primaryexp lua_primaryexp
//#endif
//#ifndef luaK_patchlist
//#define luaK_patchlist lua_luaK_patchlist
//#endif
//#ifndef getF
//#define getF lua_getF
//#endif
//#ifndef luaK_nil
//#define luaK_nil lua_luaK_nil
//#endif
//#ifndef getcached
//#define getcached lua_getcached
//#endif
//#ifndef luaD_rawrunprotected
//#define luaD_rawrunprotected lua_luaD_rawrunprotected
//#endif
//#ifndef math_toint
//#define math_toint lua_math_toint
//#endif
//#ifndef luaX_token2str
//#define luaX_token2str lua_luaX_token2str
//#endif
//#ifndef luaL_execresult
//#define luaL_execresult lua_luaL_execresult
//#endif
//#ifndef luaX_setinput
//#define luaX_setinput lua_luaX_setinput
//#endif
//#ifndef auxgetinfo
//#define auxgetinfo lua_auxgetinfo
//#endif
//#ifndef DumpFunction
//#define DumpFunction lua_DumpFunction
//#endif
//#ifndef pushutfchar
//#define pushutfchar lua_pushutfchar
//#endif
//#ifndef stackinuse
//#define stackinuse lua_stackinuse
//#endif
//#ifndef db_traceback
//#define db_traceback lua_db_traceback
//#endif
//#ifndef traversestrongtable
//#define traversestrongtable lua_traversestrongtable
//#endif
//#ifndef getfuncname
//#define getfuncname lua_getfuncname
//#endif
//#ifndef repeatstat
//#define repeatstat lua_repeatstat
//#endif
//#ifndef luaS_newlstr
//#define luaS_newlstr lua_luaS_newlstr
//#endif
//#ifndef singlestep
//#define singlestep lua_singlestep
//#endif
//#ifndef LTnum
//#define LTnum lua_LTnum
//#endif
//#ifndef luaK_patchclose
//#define luaK_patchclose lua_luaK_patchclose
//#endif
//#ifndef suffixedexp
//#define suffixedexp lua_suffixedexp
//#endif
//#ifndef l_alloc
//#define l_alloc lua_l_alloc
//#endif
//#ifndef traverseephemeron
//#define traverseephemeron lua_traverseephemeron
//#endif
//#ifndef codebinexpval
//#define codebinexpval lua_codebinexpval
//#endif
//#ifndef luaL_callmeta
//#define luaL_callmeta lua_luaL_callmeta
//#endif
//#ifndef lua_seti
//#define lua_seti lua_lua_seti
//#endif
//#ifndef skipnoopstat
//#define skipnoopstat lua_skipnoopstat
//#endif
//#ifndef luaD_callnoyield
//#define luaD_callnoyield lua_luaD_callnoyield
//#endif
//#ifndef luaB_rawequal
//#define luaB_rawequal lua_luaB_rawequal
//#endif
//#ifndef lua_gethookcount
//#define lua_gethookcount lua_lua_gethookcount
//#endif
//#ifndef luaK_jump
//#define luaK_jump lua_luaK_jump
//#endif
//#ifndef expr
//#define expr lua_expr
//#endif
//#ifndef gctm
//#define gctm lua_gctm
//#endif
//#ifndef lua_setfield
//#define lua_setfield lua_lua_setfield
//#endif
//#ifndef isinstack
//#define isinstack lua_isinstack
//#endif
//#ifndef io_type
//#define io_type lua_io_type
//#endif
//#ifndef luaL_setmetatable
//#define luaL_setmetatable lua_luaL_setmetatable
//#endif
//#ifndef luaL_unref
//#define luaL_unref lua_luaL_unref
//#endif
//#ifndef lua_pushcclosure
//#define lua_pushcclosure lua_lua_pushcclosure
//#endif
//#ifndef DumpCode
//#define DumpCode lua_DumpCode
//#endif
//#ifndef math_floor
//#define math_floor lua_math_floor
//#endif
//#ifndef luaopen_coroutine
//#define luaopen_coroutine lua_luaopen_coroutine
//#endif
//#ifndef yindex
//#define yindex lua_yindex
//#endif
//#ifndef aux_upvalue
//#define aux_upvalue lua_aux_upvalue
//#endif
//#ifndef luaT_objtypename
//#define luaT_objtypename lua_luaT_objtypename
//#endif
//#ifndef luaL_addlstring
//#define luaL_addlstring lua_luaL_addlstring
//#endif
//#ifndef luaH_get
//#define luaH_get lua_luaH_get
//#endif
//#ifndef lua_tothread
//#define lua_tothread lua_lua_tothread
//#endif
//#ifndef tofile
//#define tofile lua_tofile
//#endif
//#ifndef luaL_argerror
//#define luaL_argerror lua_luaL_argerror
//#endif
//#ifndef luaB_rawlen
//#define luaB_rawlen lua_luaB_rawlen
//#endif
//#ifndef luaB_yield
//#define luaB_yield lua_luaB_yield
//#endif
//#ifndef io_lines
//#define io_lines lua_io_lines
//#endif
//#ifndef luaM_growaux_
//#define luaM_growaux_ lua_luaM_growaux_
//#endif
//#ifndef luaL_requiref
//#define luaL_requiref lua_luaL_requiref
//#endif
//#ifndef pushnexttemplate
//#define pushnexttemplate lua_pushnexttemplate
//#endif
//#ifndef currentpc
//#define currentpc lua_currentpc
//#endif
//#ifndef treatstackoption
//#define treatstackoption lua_treatstackoption
//#endif
//#ifndef luaC_barrierback_
//#define luaC_barrierback_ lua_luaC_barrierback_
//#endif
//#ifndef luaV_tointeger
//#define luaV_tointeger lua_luaV_tointeger
//#endif
//#ifndef math_randomseed
//#define math_randomseed lua_math_randomseed
//#endif
//#ifndef luaopen_debug
//#define luaopen_debug lua_luaopen_debug
//#endif
//#ifndef searcher_Croot
//#define searcher_Croot lua_searcher_Croot
//#endif
//#ifndef luaV_lessequal
//#define luaV_lessequal lua_luaV_lessequal
//#endif
//#ifndef str_packsize
//#define str_packsize lua_str_packsize
//#endif
//#ifndef io_fclose
//#define io_fclose lua_io_fclose
//#endif
//#ifndef resizebox
//#define resizebox lua_resizebox
//#endif
//#ifndef read_chars
//#define read_chars lua_read_chars
//#endif
//#ifndef ll_require
//#define ll_require lua_ll_require
//#endif
//#ifndef lua_isuserdata
//#define lua_isuserdata lua_lua_isuserdata
//#endif
//#ifndef set2
//#define set2 lua_set2
//#endif
//#ifndef luaL_error
//#define luaL_error lua_luaL_error
//#endif
//#ifndef dischargejpc
//#define dischargejpc lua_dischargejpc
//#endif
//#ifndef luaB_select
//#define luaB_select lua_luaB_select
//#endif
//#ifndef luaL_checkudata
//#define luaL_checkudata lua_luaL_checkudata
//#endif
//#ifndef os_rename
//#define os_rename lua_os_rename
//#endif
//#ifndef createclibstable
//#define createclibstable lua_createclibstable
//#endif
//#ifndef adjust_assign
//#define adjust_assign lua_adjust_assign
//#endif
//#ifndef lua_isstring
//#define lua_isstring lua_lua_isstring
//#endif
//#ifndef io_input
//#define io_input lua_io_input
//#endif
//#ifndef start_capture
//#define start_capture lua_start_capture
//#endif
//#ifndef db_getupvalue
//#define db_getupvalue lua_db_getupvalue
//#endif
//#ifndef luaB_yieldable
//#define luaB_yieldable lua_luaB_yieldable
//#endif
//#ifndef settabss
//#define settabss lua_settabss
//#endif
//#ifndef lua_yieldk
//#define lua_yieldk lua_lua_yieldk
//#endif
//#ifndef luaU_undump
//#define luaU_undump lua_luaU_undump
//#endif
//#ifndef copy2buff
//#define copy2buff lua_copy2buff
//#endif
//#ifndef initheader
//#define initheader lua_initheader
//#endif
//#ifndef getunopr
//#define getunopr lua_getunopr
//#endif
//#ifndef adjust_varargs
//#define adjust_varargs lua_adjust_varargs
//#endif
//#ifndef capture_to_close
//#define capture_to_close lua_capture_to_close
//#endif
//#ifndef str_lower
//#define str_lower lua_str_lower
//#endif
//#ifndef math_min
//#define math_min lua_math_min
//#endif
//#ifndef packint
//#define packint lua_packint
//#endif
//#ifndef lua_pushboolean
//#define lua_pushboolean lua_lua_pushboolean
//#endif
//#ifndef digit
//#define digit lua_digit
//#endif
//#ifndef str_gsub
//#define str_gsub lua_str_gsub
//#endif
//#ifndef db_sethook
//#define db_sethook lua_db_sethook
//#endif
//#ifndef funcname
//#define funcname lua_funcname
//#endif
//#ifndef LoadUpvalues
//#define LoadUpvalues lua_LoadUpvalues
//#endif
//#ifndef lua_rawequal
//#define lua_rawequal lua_lua_rawequal
//#endif
//#ifndef fchecksize
//#define fchecksize lua_fchecksize
//#endif
//#ifndef luaD_pcall
//#define luaD_pcall lua_luaD_pcall
//#endif
//#ifndef luaB_pairs
//#define luaB_pairs lua_luaB_pairs
//#endif
//#ifndef luaK_patchtohere
//#define luaK_patchtohere lua_luaK_patchtohere
//#endif
//#ifndef getS
//#define getS lua_getS
//#endif
//#ifndef createstdfile
//#define createstdfile lua_createstdfile
//#endif
//#ifndef luaK_dischargevars
//#define luaK_dischargevars lua_luaK_dischargevars
//#endif
//#ifndef numusearray
//#define numusearray lua_numusearray
//#endif
//#ifndef entersweep
//#define entersweep lua_entersweep
//#endif
//#ifndef os_difftime
//#define os_difftime lua_os_difftime
//#endif
//#ifndef math_sqrt
//#define math_sqrt lua_math_sqrt
//#endif
//#ifndef lua_rawget
//#define lua_rawget lua_lua_rawget
//#endif
//#ifndef math_ult
//#define math_ult lua_math_ult
//#endif
//#ifndef luaopen_base
//#define luaopen_base lua_luaopen_base
//#endif
//#ifndef unityDebug
//#define unityDebug lua_unityDebug
//#endif
//#ifndef u_posrelat
//#define u_posrelat lua_u_posrelat
//#endif
//#ifndef os_clock
//#define os_clock lua_os_clock
//#endif
//#ifndef luaZ_read
//#define luaZ_read lua_luaZ_read
//#endif
//#ifndef lua_len
//#define lua_len lua_lua_len
//#endif
//#ifndef math_random
//#define math_random lua_math_random
//#endif
//#ifndef codecomp
//#define codecomp lua_codecomp
//#endif
//#ifndef callallpendingfinalizers
//#define callallpendingfinalizers lua_callallpendingfinalizers
//#endif
//#ifndef tinsert
//#define tinsert lua_tinsert
//#endif
//#ifndef runafewfinalizers
//#define runafewfinalizers lua_runafewfinalizers
//#endif
//#ifndef forbody
//#define forbody lua_forbody
//#endif
//#ifndef luaD_call
//#define luaD_call lua_luaD_call
//#endif
//#ifndef recfield
//#define recfield lua_recfield
//#endif
//#ifndef findvararg
//#define findvararg lua_findvararg
//#endif
//#ifndef new_localvar
//#define new_localvar lua_new_localvar
//#endif
//#ifndef readutf8esc
//#define readutf8esc lua_readutf8esc
//#endif
//#ifndef lua_pushnumber
//#define lua_pushnumber lua_lua_pushnumber
//#endif
//#ifndef DumpByte
//#define DumpByte lua_DumpByte
//#endif
//#ifndef luaL_setfuncs
//#define luaL_setfuncs lua_luaL_setfuncs
//#endif
//#ifndef findloader
//#define findloader lua_findloader
//#endif
//#ifndef luaL_buffinitsize
//#define luaL_buffinitsize lua_luaL_buffinitsize
//#endif
//#ifndef lua_getfield
//#define lua_getfield lua_lua_getfield
//#endif
//#ifndef boxgc
//#define boxgc lua_boxgc
//#endif
//#ifndef removeentry
//#define removeentry lua_removeentry
//#endif
//#ifndef luaF_freeproto
//#define luaF_freeproto lua_luaF_freeproto
//#endif
//#ifndef codestring
//#define codestring lua_codestring
//#endif
//#ifndef txtToken
//#define txtToken lua_txtToken
//#endif
//#ifndef tryfuncTM
//#define tryfuncTM lua_tryfuncTM
//#endif
//#ifndef luaH_getint
//#define luaH_getint lua_luaH_getint
//#endif
//#ifndef lua_createtable
//#define lua_createtable lua_lua_createtable
//#endif
//#ifndef pushnumint
//#define pushnumint lua_pushnumint
//#endif
//#ifndef luaH_setint
//#define luaH_setint lua_luaH_setint
//#endif
//#ifndef luaB_coresume
//#define luaB_coresume lua_luaB_coresume
//#endif
//#ifndef setUnityDebugLog
//#define setUnityDebugLog lua_setUnityDebugLog
//#endif
//#ifndef singlevar
//#define singlevar lua_singlevar
//#endif
//#ifndef lua_isnumber
//#define lua_isnumber lua_lua_isnumber
//#endif
//#ifndef growstack
//#define growstack lua_growstack
//#endif
//#ifndef tremove
//#define tremove lua_tremove
//#endif
//#ifndef luaE_setdebt
//#define luaE_setdebt lua_luaE_setdebt
//#endif
//#ifndef luaopen_io
//#define luaopen_io lua_luaopen_io
//#endif
//#ifndef tconcat
//#define tconcat lua_tconcat
//#endif
//#ifndef LEintfloat
//#define LEintfloat lua_LEintfloat
//#endif
//#ifndef numarith
//#define numarith lua_numarith
//#endif
//#ifndef findsetreg
//#define findsetreg lua_findsetreg
//#endif
//#ifndef check_next1
//#define check_next1 lua_check_next1
//#endif
//#ifndef luaK_getlabel
//#define luaK_getlabel lua_luaK_getlabel
//#endif
//#ifndef sweepstep
//#define sweepstep lua_sweepstep
//#endif
//#ifndef math_cos
//#define math_cos lua_math_cos
//#endif
//#ifndef luaD_throw
//#define luaD_throw lua_luaD_throw
//#endif
//#ifndef boolK
//#define boolK lua_boolK
//#endif
//#ifndef test_eof
//#define test_eof lua_test_eof
//#endif
//#ifndef DumpUpvalues
//#define DumpUpvalues lua_DumpUpvalues
//#endif
//#ifndef lua_settable
//#define lua_settable lua_lua_settable
//#endif
//#ifndef internshrstr
//#define internshrstr lua_internshrstr
//#endif
//#ifndef condjump
//#define condjump lua_condjump
//#endif
//#ifndef luaC_fullgc
//#define luaC_fullgc lua_luaC_fullgc
//#endif
//#ifndef DumpHeader
//#define DumpHeader lua_DumpHeader
//#endif
//#ifndef luaB_next
//#define luaB_next lua_luaB_next
//#endif
//#ifndef lua_xmove
//#define lua_xmove lua_lua_xmove
//#endif
//#ifndef searchpath
//#define searchpath lua_searchpath
//#endif
//#ifndef read_all
//#define read_all lua_read_all
//#endif
//#ifndef luaF_findupval
//#define luaF_findupval lua_luaF_findupval
//#endif
//#ifndef lua_getglobal
//#define lua_getglobal lua_lua_getglobal
//#endif
//#ifndef clearkeys
//#define clearkeys lua_clearkeys
//#endif
//#ifndef getobjname
//#define getobjname lua_getobjname
//#endif
//#ifndef recover
//#define recover lua_recover
//#endif
//#ifndef getboolfield
//#define getboolfield lua_getboolfield
//#endif
//#ifndef DumpNumber
//#define DumpNumber lua_DumpNumber
//#endif
//#ifndef lua_checkstack
//#define lua_checkstack lua_lua_checkstack
//#endif
//#ifndef scanformat
//#define scanformat lua_scanformat
//#endif
//#ifndef freereg
//#define freereg lua_freereg
//#endif
//#ifndef math_type
//#define math_type lua_math_type
//#endif
//#ifndef field
//#define field lua_field
//#endif
//#ifndef luaG_typeerror
//#define luaG_typeerror lua_luaG_typeerror
//#endif
//#ifndef DumpProtos
//#define DumpProtos lua_DumpProtos
//#endif
//#ifndef luaB_rawget
//#define luaB_rawget lua_luaB_rawget
//#endif
//#ifndef traverseCclosure
//#define traverseCclosure lua_traverseCclosure
//#endif
//#ifndef open_func
//#define open_func lua_open_func
//#endif
//#ifndef luaopen_string
//#define luaopen_string lua_luaopen_string
//#endif
//#ifndef kname
//#define kname lua_kname
//#endif
//#ifndef lua_pushthread
//#define lua_pushthread lua_lua_pushthread
//#endif
//#ifndef math_modf
//#define math_modf lua_math_modf
//#endif
//#ifndef setpath
//#define setpath lua_setpath
//#endif
//#ifndef constructor
//#define constructor lua_constructor
//#endif
//#ifndef luaL_getmetafield
//#define luaL_getmetafield lua_luaL_getmetafield
//#endif
//#ifndef luaK_intK
//#define luaK_intK lua_luaK_intK
//#endif
//#ifndef luaD_hook
//#define luaD_hook lua_luaD_hook
//#endif
//#ifndef forlimit
//#define forlimit lua_forlimit
//#endif
//#ifndef db_gethook
//#define db_gethook lua_db_gethook
//#endif
//#ifndef validop
//#define validop lua_validop
//#endif
//#ifndef luaC_newobj
//#define luaC_newobj lua_luaC_newobj
//#endif
//#ifndef luaH_set
//#define luaH_set lua_luaH_set
//#endif
//#ifndef currentline
//#define currentline lua_currentline
//#endif
//#ifndef luaK_exp2nextreg
//#define luaK_exp2nextreg lua_luaK_exp2nextreg
//#endif
//#ifndef luaB_collectgarbage
//#define luaB_collectgarbage lua_luaB_collectgarbage
//#endif
//#ifndef lua_pushinteger
//#define lua_pushinteger lua_lua_pushinteger
//#endif
//#ifndef io_flush
//#define io_flush lua_io_flush
//#endif
//#ifndef f_gc
//#define f_gc lua_f_gc
//#endif
////#ifndef l_checkmode
////#define l_checkmode lua_l_checkmode
////#endif
//#ifndef str_format
//#define str_format lua_str_format
//#endif
//#ifndef findindex
//#define findindex lua_findindex
//#endif
//#ifndef luaB_cowrap
//#define luaB_cowrap lua_luaB_cowrap
//#endif
//#ifndef g_write
//#define g_write lua_g_write
//#endif
//#ifndef luaF_newproto
//#define luaF_newproto lua_luaF_newproto
//#endif
//#ifndef ipairsaux
//#define ipairsaux lua_ipairsaux
//#endif
//#ifndef labelstat
//#define labelstat lua_labelstat
//#endif
//#ifndef luaB_xpcall
//#define luaB_xpcall lua_luaB_xpcall
//#endif
//#ifndef luaX_init
//#define luaX_init lua_luaX_init
//#endif
//#ifndef f_tostring
//#define f_tostring lua_f_tostring
//#endif
//#ifndef filterpc
//#define filterpc lua_filterpc
//#endif
//#ifndef DumpConstants
//#define DumpConstants lua_DumpConstants
//#endif
//#ifndef breaklabel
//#define breaklabel lua_breaklabel
//#endif
//#ifndef GCTM
//#define GCTM lua_GCTM
//#endif
//#ifndef str_reverse
//#define str_reverse lua_str_reverse
//#endif
//#ifndef aux_lines
//#define aux_lines lua_aux_lines
//#endif
//#ifndef closelistfield
//#define closelistfield lua_closelistfield
//#endif
//#ifndef luaU_dump
//#define luaU_dump lua_luaU_dump
//#endif
//#ifndef numusehash
//#define numusehash lua_numusehash
//#endif
//#ifndef math_acos
//#define math_acos lua_math_acos
//#endif
//#ifndef lua_tolstring
//#define lua_tolstring lua_lua_tolstring
//#endif
//#ifndef iter_codes
//#define iter_codes lua_iter_codes
//#endif
//#ifndef dothecall
//#define dothecall lua_dothecall
//#endif
//#ifndef math_exp
//#define math_exp lua_math_exp
//#endif
//#ifndef convergeephemerons
//#define convergeephemerons lua_convergeephemerons
//#endif
//#ifndef leaveblock
//#define leaveblock lua_leaveblock
//#endif
//#ifndef iscleared
//#define iscleared lua_iscleared
//#endif
//#ifndef checknext
//#define checknext lua_checknext
//#endif
//#ifndef llex
//#define llex lua_llex
//#endif
//#ifndef opencheck
//#define opencheck lua_opencheck
//#endif
//#ifndef mainposition
//#define mainposition lua_mainposition
//#endif
//#ifndef nospecials
//#define nospecials lua_nospecials
//#endif
//#ifndef lua_callk
//#define lua_callk lua_lua_callk
//#endif
//#ifndef luaK_infix
//#define luaK_infix lua_luaK_infix
//#endif
//#ifndef jumponcond
//#define jumponcond lua_jumponcond
//#endif
//#ifndef math_log
//#define math_log lua_math_log
//#endif
//#ifndef reprepstate
//#define reprepstate lua_reprepstate
//#endif
//#ifndef lua_type
//#define lua_type lua_lua_type
//#endif
//#ifndef luaL_checkoption
//#define luaL_checkoption lua_luaL_checkoption
//#endif
//#ifndef typeerror
//#define typeerror lua_typeerror
//#endif
//#ifndef luaL_gsub
//#define luaL_gsub lua_luaL_gsub
//#endif
//#ifndef f_setvbuf
//#define f_setvbuf lua_f_setvbuf
//#endif
//#ifndef db_debug
//#define db_debug lua_db_debug
//#endif
//#ifndef getlocvar
//#define getlocvar lua_getlocvar
//#endif
//#ifndef luaX_next
//#define luaX_next lua_luaX_next
//#endif
//#ifndef lua_iscfunction
//#define lua_iscfunction lua_lua_iscfunction
//#endif
//#ifndef luaX_syntaxerror
//#define luaX_syntaxerror lua_luaX_syntaxerror
//#endif
//#ifndef luaT_callbinTM
//#define luaT_callbinTM lua_luaT_callbinTM
//#endif
//#ifndef LoadInteger
//#define LoadInteger lua_LoadInteger
//#endif
//#ifndef luaO_pushvfstring
//#define luaO_pushvfstring lua_luaO_pushvfstring
//#endif
//#ifndef luaX_lookahead
//#define luaX_lookahead lua_luaX_lookahead
//#endif
//#ifndef f_lines
//#define f_lines lua_f_lines
//#endif
//#ifndef db_upvaluejoin
//#define db_upvaluejoin lua_db_upvaluejoin
//#endif
//#ifndef match_class
//#define match_class lua_match_class
//#endif
//#ifndef adjustlocalvars
//#define adjustlocalvars lua_adjustlocalvars
//#endif
//#ifndef pushglobalfuncname
//#define pushglobalfuncname lua_pushglobalfuncname
//#endif
//#ifndef math_abs
//#define math_abs lua_math_abs
//#endif
//#ifndef lua_gettable
//#define lua_gettable lua_lua_gettable
//#endif
//#ifndef pushstr
//#define pushstr lua_pushstr
//#endif
//#ifndef checkname
//#define checkname lua_checkname
//#endif
//#ifndef check_capture
//#define check_capture lua_check_capture
//#endif
//#ifndef discharge2reg
//#define discharge2reg lua_discharge2reg
//#endif
//#ifndef getoption
//#define getoption lua_getoption
//#endif
//#ifndef whilestat
//#define whilestat lua_whilestat
//#endif
//#ifndef addprototype
//#define addprototype lua_addprototype
//#endif
//#ifndef luaL_pushresult
//#define luaL_pushresult lua_luaL_pushresult
//#endif
//#ifndef db_getmetatable
//#define db_getmetatable lua_db_getmetatable
//#endif
//#ifndef LoadNumber
//#define LoadNumber lua_LoadNumber
//#endif
//#ifndef luaT_init
//#define luaT_init lua_luaT_init
//#endif
//#ifndef getgeneric
//#define getgeneric lua_getgeneric
//#endif
//#ifndef luaS_remove
//#define luaS_remove lua_luaS_remove
//#endif
//#ifndef luaK_setreturns
//#define luaK_setreturns lua_luaK_setreturns
//#endif
//#ifndef str_checkname
//#define str_checkname lua_str_checkname
//#endif
//#ifndef LoadProtos
//#define LoadProtos lua_LoadProtos
//#endif
//#ifndef freeLclosure
//#define freeLclosure lua_freeLclosure
//#endif
//#ifndef callhook
//#define callhook lua_callhook
//#endif
//#ifndef funcstat
//#define funcstat lua_funcstat
//#endif
//#ifndef skipBOM
//#define skipBOM lua_skipBOM
//#endif
//#ifndef os_exit
//#define os_exit lua_os_exit
//#endif
//#ifndef init_registry
//#define init_registry lua_init_registry
//#endif
//#ifndef lua_geti
//#define lua_geti lua_lua_geti
//#endif
//#ifndef searchupvalue
//#define searchupvalue lua_searchupvalue
//#endif
//#ifndef block_follow
//#define block_follow lua_block_follow
//#endif
//#ifndef movegotosout
//#define movegotosout lua_movegotosout
//#endif
//#ifndef countint
//#define countint lua_countint
//#endif
//#ifndef luaF_getlocalname
//#define luaF_getlocalname lua_luaF_getlocalname
//#endif
//#ifndef luaL_where
//#define luaL_where lua_luaL_where
//#endif
//#ifndef lua_pcallk
//#define lua_pcallk lua_lua_pcallk
//#endif
//#ifndef forstat
//#define forstat lua_forstat
//#endif
//#ifndef listfield
//#define listfield lua_listfield
//#endif
//#ifndef db_getlocal
//#define db_getlocal lua_db_getlocal
//#endif
//#ifndef forlist
//#define forlist lua_forlist
//#endif
//#ifndef sweeplist
//#define sweeplist lua_sweeplist
//#endif
//#ifndef luaV_finishOp
//#define luaV_finishOp lua_luaV_finishOp
//#endif
//#ifndef lua_load
//#define lua_load lua_lua_load
//#endif
//#ifndef lua_pushnil
//#define lua_pushnil lua_lua_pushnil
//#endif
//#ifndef luaK_concat
//#define luaK_concat lua_luaK_concat
//#endif
//#ifndef str_byte
//#define str_byte lua_str_byte
//#endif
//#ifndef luaK_setoneret
//#define luaK_setoneret lua_luaK_setoneret
//#endif
//#ifndef lua_sethook
//#define lua_sethook lua_lua_sethook
//#endif
//#ifndef gmatch
//#define gmatch lua_gmatch
//#endif
//#ifndef correctstack
//#define correctstack lua_correctstack
//#endif
//#ifndef check_next2
//#define check_next2 lua_check_next2
//#endif
//#ifndef lua_getuservalue
//#define lua_getuservalue lua_lua_getuservalue
//#endif
//#ifndef l_checktime
//#define l_checktime lua_l_checktime
//#endif
//#ifndef luaC_checkfinalizer
//#define luaC_checkfinalizer lua_luaC_checkfinalizer
//#endif
//#ifndef getnumlimit
//#define getnumlimit lua_getnumlimit
//#endif
//#ifndef createsearcherstable
//#define createsearcherstable lua_createsearcherstable
//#endif
//#ifndef lsys_unloadlib
//#define lsys_unloadlib lua_lsys_unloadlib
//#endif
//#ifndef luaS_hashlongstr
//#define luaS_hashlongstr lua_luaS_hashlongstr
//#endif
//#ifndef checkupval
//#define checkupval lua_checkupval
//#endif
//#ifndef getfield
//#define getfield luaS_getfield
//#endif
//#ifndef udata2finalize
//#define udata2finalize lua_udata2finalize
//#endif
//#ifndef lua_typename
//#define lua_typename lua_lua_typename
//#endif
//#ifndef codeextraarg
//#define codeextraarg lua_codeextraarg
//#endif
//#ifndef getjumpcontrol
//#define getjumpcontrol lua_getjumpcontrol
//#endif
//#ifndef exp1
//#define exp1 lua_exp1
//#endif
//#ifndef str_dump
//#define str_dump lua_str_dump
//#endif
//#ifndef luaG_opinterror
//#define luaG_opinterror lua_luaG_opinterror
//#endif
//#ifndef lua_isyieldable
//#define lua_isyieldable lua_lua_isyieldable
//#endif
//#ifndef constfolding
//#define constfolding lua_constfolding
//#endif
//#ifndef auxsort
//#define auxsort lua_auxsort
//#endif
//#ifndef sort
//#define sort lua_sort
//#endif
//#ifndef setallfields
//#define setallfields lua_setallfields
//#endif
//#ifndef db_upvalueid
//#define db_upvalueid lua_db_upvalueid
//#endif
//#ifndef add_s
//#define add_s lua_add_s
//#endif
//#ifndef utfchar
//#define utfchar lua_utfchar
//#endif
//#ifndef createstrobj
//#define createstrobj lua_createstrobj
//#endif
//#ifndef skip_sep
//#define skip_sep lua_skip_sep
//#endif
//#ifndef io_pclose
//#define io_pclose lua_io_pclose
//#endif
//#ifndef read_string
//#define read_string lua_read_string
//#endif
//#ifndef getiofile
//#define getiofile lua_getiofile
//#endif
//#ifndef checkdp
//#define checkdp lua_checkdp
//#endif
//#ifndef tag_error
//#define tag_error lua_tag_error
//#endif
//#ifndef luaV_shiftl
//#define luaV_shiftl lua_luaV_shiftl
//#endif
//#ifndef exprstat
//#define exprstat lua_exprstat
//#endif
//#ifndef aux_close
//#define aux_close lua_aux_close
//#endif
//#ifndef luaD_poscall
//#define luaD_poscall lua_luaD_poscall
//#endif
//#ifndef luaC_runtilstate
//#define luaC_runtilstate lua_luaC_runtilstate
//#endif
//#ifndef finishpcall
//#define finishpcall lua_finishpcall
//#endif
//#ifndef lua_gethook
//#define lua_gethook lua_lua_gethook
//#endif
//#ifndef luaB_tostring
//#define luaB_tostring lua_luaB_tostring
//#endif
//#ifndef db_setlocal
//#define db_setlocal lua_db_setlocal
//#endif
//#ifndef str_len
//#define str_len lua_str_len
//#endif
//#ifndef luaL_loadstring
//#define luaL_loadstring lua_luaL_loadstring
//#endif
//#ifndef luaE_freeCI
//#define luaE_freeCI lua_luaE_freeCI
//#endif
//#ifndef add_value
//#define add_value lua_add_value
//#endif
//#ifndef checkmode
//#define checkmode lua_checkmode
//#endif
//#ifndef luaV_div
//#define luaV_div lua_luaV_div
//#endif
//#ifndef lua_pushvalue
//#define lua_pushvalue lua_lua_pushvalue
//#endif
//#ifndef newbox
//#define newbox lua_newbox
//#endif
//#ifndef luaD_growstack
//#define luaD_growstack lua_luaD_growstack
//#endif
//#ifndef luaV_concat
//#define luaV_concat lua_luaV_concat
//#endif
//#ifndef luaL_pushresultsize
//#define luaL_pushresultsize lua_luaL_pushresultsize
//#endif
//#ifndef luaM_toobig
//#define luaM_toobig lua_luaM_toobig
//#endif
//#ifndef lookforfunc
//#define lookforfunc lua_lookforfunc
//#endif
//#ifndef luaL_traceback
//#define luaL_traceback lua_luaL_traceback
//#endif
//#ifndef gotostat
//#define gotostat lua_gotostat
//#endif
//#ifndef nextc
//#define nextc lua_nextc
//#endif
//#ifndef unroll
//#define unroll lua_unroll
//#endif
//#ifndef db_setupvalue
//#define db_setupvalue lua_db_setupvalue
//#endif
//#ifndef lua_version
//#define lua_version lua_lua_version
//#endif
//#ifndef luaV_tonumber_
//#define luaV_tonumber_ lua_luaV_tonumber_
//#endif
//#ifndef inclinenumber
//#define inclinenumber lua_inclinenumber
//#endif
//#ifndef os_setlocale
//#define os_setlocale lua_os_setlocale
//#endif
//#ifndef luaL_checklstring
//#define luaL_checklstring lua_luaL_checklstring
//#endif
////#ifndef reverse
////#define reverse lua_reverse
////#endif
//#ifndef luaK_checkstack
//#define luaK_checkstack lua_luaK_checkstack
//#endif
//#ifndef intarith
//#define intarith lua_intarith
//#endif
//#ifndef fixjump
//#define fixjump lua_fixjump
//#endif
//#ifndef luaopen_math
//#define luaopen_math lua_luaopen_math
//#endif
//#ifndef str_match
//#define str_match lua_str_match
//#endif
//#ifndef lua_rawgeti
//#define lua_rawgeti lua_lua_rawgeti
//#endif
//#ifndef getdebt
//#define getdebt lua_getdebt
//#endif
//#ifndef readhexaesc
//#define readhexaesc lua_readhexaesc
//#endif
//#ifndef l_strcmp
//#define l_strcmp lua_l_strcmp
//#endif
//#ifndef lua_rawseti
//#define lua_rawseti lua_lua_rawseti
//#endif
//#ifndef lmemfind
//#define lmemfind lua_lmemfind
//#endif
//#ifndef sort_comp
//#define sort_comp lua_sort_comp
//#endif
//#ifndef explist
//#define explist lua_explist
//#endif
//#ifndef luaS_new
//#define luaS_new lua_luaS_new
//#endif
//#ifndef push_captures
//#define push_captures lua_push_captures
//#endif
//#ifndef searcher_preload
//#define searcher_preload lua_searcher_preload
//#endif
//#ifndef end_capture
//#define end_capture lua_end_capture
//#endif
//#ifndef LoadConstants
//#define LoadConstants lua_LoadConstants
//#endif
//#ifndef io_open
//#define io_open lua_io_open
//#endif
//#ifndef luaK_self
//#define luaK_self lua_luaK_self
//#endif
//#ifndef luaL_checkstack
//#define luaL_checkstack lua_luaL_checkstack
//#endif
//#ifndef traversethread
//#define traversethread lua_traversethread
//#endif
//#ifndef lua_newthread
//#define lua_newthread lua_lua_newthread
//#endif
//#ifndef luaS_newudata
//#define luaS_newudata lua_luaS_newudata
//#endif
//#ifndef luaH_getstr
//#define luaH_getstr lua_luaH_getstr
//#endif
//#ifndef luaL_optnumber
//#define luaL_optnumber lua_luaL_optnumber
//#endif
//#ifndef prepstate
//#define prepstate lua_prepstate
//#endif
//#ifndef resume_error
//#define resume_error lua_resume_error
//#endif
//#ifndef errorlimit
//#define errorlimit lua_errorlimit
//#endif
//#ifndef luaB_auxwrap
//#define luaB_auxwrap lua_luaB_auxwrap
//#endif
//#ifndef luaK_exp2anyreg
//#define luaK_exp2anyreg lua_luaK_exp2anyreg
//#endif
//#ifndef tonumeral
//#define tonumeral lua_tonumeral
//#endif
//#ifndef luaL_optlstring
//#define luaL_optlstring lua_luaL_optlstring
//#endif
//#ifndef read_long_string
//#define read_long_string lua_read_long_string
//#endif
//#ifndef os_getenv
//#define os_getenv lua_os_getenv
//#endif
//#ifndef test2
//#define test2 lua_test2
//#endif
//#ifndef markbeingfnz
//#define markbeingfnz lua_markbeingfnz
//#endif
//#ifndef luaB_load
//#define luaB_load lua_luaB_load
//#endif
//#ifndef os_execute
//#define os_execute lua_os_execute
//#endif
//#ifndef posrelat
//#define posrelat lua_posrelat
//#endif
//#ifndef db_setmetatable
//#define db_setmetatable lua_db_setmetatable
//#endif
//#ifndef luaK_exp2anyregup
//#define luaK_exp2anyregup lua_luaK_exp2anyregup
//#endif
//#ifndef checklimit
//#define checklimit lua_checklimit
//#endif
//#ifndef luaC_fix
//#define luaC_fix lua_luaC_fix
//#endif
//#ifndef lua_setuservalue
//#define lua_setuservalue lua_lua_setuservalue
//#endif
//#ifndef luaD_precall
//#define luaD_precall lua_luaD_precall
//#endif
//#ifndef lua_tocfunction
//#define lua_tocfunction lua_lua_tocfunction
//#endif
//#ifndef lua_getinfo
//#define lua_getinfo lua_lua_getinfo
//#endif
//#ifndef auxsetnode
//#define auxsetnode lua_auxsetnode
//#endif
//#ifndef LTintfloat
//#define LTintfloat lua_LTintfloat
//#endif
//#ifndef luaT_callTM
//#define luaT_callTM lua_luaT_callTM
//#endif
//#ifndef os_tmpname
//#define os_tmpname lua_os_tmpname
//#endif
//#ifndef luaL_checkinteger
//#define luaL_checkinteger lua_luaL_checkinteger
//#endif
//#ifndef f_flush
//#define f_flush lua_f_flush
//#endif
//#ifndef getfreepos
//#define getfreepos lua_getfreepos
//#endif
//#ifndef lua_copy
//#define lua_copy lua_lua_copy
//#endif
//#ifndef tmove
//#define tmove lua_tmove
//#endif
//#ifndef math_ceil
//#define math_ceil lua_math_ceil
//#endif
//#ifndef f_parser
//#define f_parser lua_f_parser
//#endif
//#ifndef lexerror
//#define lexerror lua_lexerror
//#endif
//#ifndef findpcall
//#define findpcall lua_findpcall
//#endif
//#ifndef statlist
//#define statlist lua_statlist
//#endif
//#ifndef luaF_newCclosure
//#define luaF_newCclosure lua_luaF_newCclosure
//#endif
//#ifndef retstat
//#define retstat lua_retstat
//#endif
//#ifndef luaK_goiffalse
//#define luaK_goiffalse lua_luaK_goiffalse
//#endif
//#ifndef lua_status
//#define lua_status lua_lua_status
//#endif
//#ifndef lua_setallocf
//#define lua_setallocf lua_lua_setallocf
//#endif
//#ifndef utf8_decode
//#define utf8_decode lua_utf8_decode
//#endif
//#ifndef luaG_runerror
//#define luaG_runerror lua_luaG_runerror
//#endif
//#ifndef checkstack
//#define checkstack luaS_checkstack
//#endif
//#ifndef os_remove
//#define os_remove lua_os_remove
//#endif
//#ifndef remarkupvals
//#define remarkupvals lua_remarkupvals
//#endif
//#ifndef str_find
//#define str_find lua_str_find
//#endif
//#ifndef findlabel
//#define findlabel lua_findlabel
//#endif
//#ifndef f_seek
//#define f_seek lua_f_seek
//#endif
//#ifndef luaL_getsubtable
//#define luaL_getsubtable lua_luaL_getsubtable
//#endif
//#ifndef luaL_testudata
//#define luaL_testudata lua_luaL_testudata
//#endif
//#ifndef need_value
//#define need_value lua_need_value
//#endif
//#ifndef preinit_thread
//#define preinit_thread lua_preinit_thread
//#endif
//#ifndef lua_gethookmask
//#define lua_gethookmask lua_lua_gethookmask
//#endif
//#ifndef stackerror
//#define stackerror lua_stackerror
//#endif
//#ifndef luaL_addvalue
//#define luaL_addvalue lua_luaL_addvalue
//#endif
//#ifndef luaL_newmetatable
//#define luaL_newmetatable lua_luaL_newmetatable
//#endif
//#ifndef unmakemask
//#define unmakemask lua_unmakemask
//#endif
//#ifndef lua_setupvalue
//#define lua_setupvalue lua_lua_setupvalue
//#endif
//#ifndef dofilecont
//#define dofilecont lua_dofilecont
//#endif
//#ifndef luaK_fixline
//#define luaK_fixline lua_luaK_fixline
//#endif
//#ifndef luaC_upvalbarrier_
//#define luaC_upvalbarrier_ lua_luaC_upvalbarrier_
//#endif
//#ifndef freestack
//#define freestack lua_freestack
//#endif
//#ifndef propagateall
//#define propagateall lua_propagateall
//#endif
//#ifndef LoadDebug
//#define LoadDebug lua_LoadDebug
//#endif
//#ifndef mainfunc
//#define mainfunc lua_mainfunc
//#endif
//#ifndef luaT_trybinTM
//#define luaT_trybinTM lua_luaT_trybinTM
//#endif
//#ifndef copywithendian
//#define copywithendian lua_copywithendian
//#endif
//#ifndef l_str2dloc
//#define l_str2dloc lua_l_str2dloc
//#endif
//#ifndef collectvalidlines
//#define collectvalidlines lua_collectvalidlines
//#endif
//#ifndef getco
//#define getco lua_getco
//#endif
//#ifndef enterlevel
//#define enterlevel lua_enterlevel
//#endif
//#ifndef makeseed
//#define makeseed lua_makeseed
//#endif
//#ifndef getupvalref
//#define getupvalref lua_getupvalref
//#endif
//#ifndef DumpDebug
//#define DumpDebug lua_DumpDebug
//#endif
//#ifndef read_line
//#define read_line lua_read_line
//#endif
//#ifndef luaC_upvdeccount
//#define luaC_upvdeccount lua_luaC_upvdeccount
//#endif
//#ifndef DumpString
//#define DumpString lua_DumpString
//#endif
//#ifndef findlast
//#define findlast lua_findlast
//#endif
//#ifndef lua_next
//#define lua_next lua_lua_next
//#endif
//#ifndef luaopen_utf8
//#define luaopen_utf8 lua_luaopen_utf8
//#endif
//#ifndef luaB_print
//#define luaB_print lua_luaB_print
//#endif
//#ifndef luaD_reallocstack
//#define luaD_reallocstack lua_luaD_reallocstack
//#endif
//#ifndef byteoffset
//#define byteoffset lua_byteoffset
//#endif
//#ifndef gmatch_aux
//#define gmatch_aux lua_gmatch_aux
//#endif
//#ifndef lua_toboolean
//#define lua_toboolean lua_lua_toboolean
//#endif
//#ifndef separatetobefnz
//#define separatetobefnz lua_separatetobefnz
//#endif
//#ifndef exp2reg
//#define exp2reg lua_exp2reg
//#endif
//#ifndef checkload
//#define checkload lua_checkload
//#endif
//#ifndef luaG_traceexec
//#define luaG_traceexec lua_luaG_traceexec
//#endif
//#ifndef luaD_shrinkstack
//#define luaD_shrinkstack lua_luaD_shrinkstack
//#endif
//#ifndef settabsb
//#define settabsb lua_settabsb
//#endif
//#ifndef stack_init
//#define stack_init lua_stack_init
//#endif
//#ifndef newupvalue
//#define newupvalue lua_newupvalue
//#endif
//#ifndef luaL_len
//#define luaL_len lua_luaL_len
//#endif
//#ifndef luaO_fb2int
//#define luaO_fb2int lua_luaO_fb2int
//#endif
//#ifndef freeobj
//#define freeobj lua_freeobj
//#endif
//#ifndef lua_absindex
//#define lua_absindex lua_lua_absindex
//#endif
//#ifndef luaE_shrinkCI
//#define luaE_shrinkCI lua_luaE_shrinkCI
//#endif
//#ifndef getjump
//#define getjump lua_getjump
//#endif
//#ifndef luaB_costatus
//#define luaB_costatus lua_luaB_costatus
//#endif
//#ifndef luaG_tointerror
//#define luaG_tointerror lua_luaG_tointerror
//#endif
//#ifndef luaB_cocreate
//#define luaB_cocreate lua_luaB_cocreate
//#endif
//#ifndef fieldsel
//#define fieldsel lua_fieldsel
//#endif
//#ifndef lua_getmetatable
//#define lua_getmetatable lua_lua_getmetatable
//#endif
//#ifndef luaK_reserveregs
//#define luaK_reserveregs lua_luaK_reserveregs
//#endif
//#ifndef luaS_resize
//#define luaS_resize lua_luaS_resize
//#endif
//#ifndef codeunexpval
//#define codeunexpval lua_codeunexpval
//#endif
//#ifndef assignment
//#define assignment lua_assignment
//#endif
//#ifndef luaO_chunkid
//#define luaO_chunkid lua_luaO_chunkid
//#endif
//#ifndef luaG_ordererror
//#define luaG_ordererror lua_luaG_ordererror
//#endif
//#ifndef auxsetstr
//#define auxsetstr lua_auxsetstr
//#endif
//#ifndef lua_newstate
//#define lua_newstate lua_lua_newstate
//#endif
//#ifndef luaH_resize
//#define luaH_resize lua_luaH_resize
//#endif
//#ifndef lua_setlocal
//#define lua_setlocal lua_lua_setlocal
//#endif
//#ifndef luaO_tostring
//#define luaO_tostring lua_luaO_tostring
//#endif
//#ifndef luaL_checknumber
//#define luaL_checknumber lua_luaL_checknumber
//#endif
//#ifndef lua_error
//#define lua_error lua_lua_error
//#endif
//#ifndef lua_touserdata
//#define lua_touserdata lua_lua_touserdata
//#endif
//#ifndef luaH_next
//#define luaH_next lua_luaH_next
//#endif
//#ifndef luaS_init
//#define luaS_init lua_luaS_init
//#endif
//#ifndef settabsi
//#define settabsi lua_settabsi
//#endif
//#ifndef str_unpack
//#define str_unpack lua_str_unpack
//#endif
//#ifndef clearvalues
//#define clearvalues lua_clearvalues
//#endif
//#ifndef index2addr
//#define index2addr lua_index2addr
//#endif
//#ifndef luaH_resizearray
//#define luaH_resizearray lua_luaH_resizearray
//#endif
//#ifndef newprefile
//#define newprefile lua_newprefile
//#endif
//#ifndef lua_gettop
//#define lua_gettop lua_lua_gettop
//#endif
//#ifndef ifstat
//#define ifstat lua_ifstat
//#endif
//#ifndef luaV_equalobj
//#define luaV_equalobj lua_luaV_equalobj
//#endif
//#ifndef sweeptolive
//#define sweeptolive lua_sweeptolive
//#endif
//#ifndef nilK
//#define nilK lua_nilK
//#endif
//#ifndef luaS_hash
//#define luaS_hash lua_luaS_hash
//#endif
//#ifndef codeclosure
//#define codeclosure lua_codeclosure
//#endif
//#ifndef lua_rotate
//#define lua_rotate lua_lua_rotate
//#endif
//#ifndef luaL_loadbufferx
//#define luaL_loadbufferx lua_luaL_loadbufferx
//#endif
//#ifndef simpleexp
//#define simpleexp lua_simpleexp
//#endif
//#ifndef subexpr
//#define subexpr lua_subexpr
//#endif
//#ifndef iter_aux
//#define iter_aux lua_iter_aux
//#endif
//#ifndef testnext
//#define testnext lua_testnext
//#endif
//#ifndef finishCcall
//#define finishCcall lua_finishCcall
//#endif
//#ifndef luaG_errormsg
//#define luaG_errormsg lua_luaG_errormsg
//#endif
//#ifndef luaM_realloc_
//#define luaM_realloc_ lua_luaM_realloc_
//#endif
//#ifndef lua_getupvalue
//#define lua_getupvalue lua_lua_getupvalue
//#endif
//#ifndef registerlocalvar
//#define registerlocalvar lua_registerlocalvar
//#endif
//#ifndef lua_isinteger
//#define lua_isinteger lua_lua_isinteger
//#endif
//#ifndef max_expand
//#define max_expand lua_max_expand
//#endif
//#ifndef searchvar
//#define searchvar lua_searchvar
//#endif
//#ifndef lua_upvalueid
//#define lua_upvalueid lua_lua_upvalueid
//#endif
//#ifndef addquoted
//#define addquoted lua_addquoted
//#endif
//#ifndef io_readline
//#define io_readline lua_io_readline
//#endif
//#ifndef luaB_type
//#define luaB_type lua_luaB_type
//#endif
//#ifndef addlenmod
//#define addlenmod lua_addlenmod
//#endif
//#ifndef luaV_mod
//#define luaV_mod lua_luaV_mod
//#endif
//#ifndef luaB_pcall
//#define luaB_pcall lua_luaB_pcall
//#endif
//#ifndef luaK_exp2RK
//#define luaK_exp2RK lua_luaK_exp2RK
//#endif
//#ifndef parlist
//#define parlist lua_parlist
//#endif
//#ifndef luaC_barrier_
//#define luaC_barrier_ lua_luaC_barrier_
//#endif
//#ifndef lua_dump
//#define lua_dump lua_lua_dump
//#endif
//#ifndef read_numeral
//#define read_numeral lua_read_numeral
//#endif
//#ifndef luaH_getn
//#define luaH_getn lua_luaH_getn
//#endif
//#ifndef str_pack
//#define str_pack lua_str_pack
//#endif
//#ifndef gethexa
//#define gethexa lua_gethexa
//#endif
//#ifndef writer
//#define writer lua_writer
//#endif
//#ifndef codenot
//#define codenot lua_codenot
//#endif
//#ifndef luaL_openlibs
//#define luaL_openlibs lua_luaL_openlibs
//#endif
//#ifndef funcargs
//#define funcargs lua_funcargs
//#endif
//#ifndef lua_resume
//#define lua_resume lua_lua_resume
//#endif
//#ifndef LoadString
//#define LoadString lua_LoadString
//#endif
//#ifndef l_str2int
//#define l_str2int lua_l_str2int
//#endif
//#ifndef luaY_parser
//#define luaY_parser lua_luaY_parser
//#endif
//#ifndef luaB_dofile
//#define luaB_dofile lua_luaB_dofile
//#endif
//#ifndef f_luaopen
//#define f_luaopen lua_f_luaopen
//#endif
//#ifndef lua_stringtonumber
//#define lua_stringtonumber lua_lua_stringtonumber
//#endif
//#ifndef lastlevel
//#define lastlevel lua_lastlevel
//#endif
//#ifndef createmetatable
//#define createmetatable lua_createmetatable
//#endif
//#ifndef block
//#define block lua_block
//#endif
//#ifndef findfield
//#define findfield lua_findfield
//#endif
//#ifndef lua_tonumberx
//#define lua_tonumberx lua_lua_tonumberx
//#endif
//#ifndef arrayindex
//#define arrayindex lua_arrayindex
//#endif
//#ifndef luaB_tonumber
//#define luaB_tonumber lua_luaB_tonumber
//#endif
//#ifndef removevalues
//#define removevalues lua_removevalues
//#endif
//#ifndef luaB_ipairs
//#define luaB_ipairs lua_luaB_ipairs
//#endif
//#ifndef lua_concat
//#define lua_concat lua_lua_concat
//#endif
//#ifndef classend
//#define classend lua_classend
//#endif
//#ifndef lua_settop
//#define lua_settop lua_lua_settop
//#endif
//#ifndef f_read
//#define f_read lua_f_read
//#endif
//#ifndef luaL_buffinit
//#define luaL_buffinit lua_luaL_buffinit
//#endif
//#ifndef test_then_block
//#define test_then_block lua_test_then_block
//#endif
//#ifndef checkliteral
//#define checkliteral lua_checkliteral
//#endif
//#ifndef luaO_utf8esc
//#define luaO_utf8esc lua_luaO_utf8esc
//#endif
//#ifndef io_read
//#define io_read lua_io_read
//#endif
//#ifndef luaB_error
//#define luaB_error lua_luaB_error
//#endif
//#ifndef readdecesc
//#define readdecesc lua_readdecesc
//#endif
//#ifndef upvalname
//#define upvalname lua_upvalname
//#endif
//#ifndef codepoint
//#define codepoint lua_codepoint
//#endif
//#ifndef varinfo
//#define varinfo lua_varinfo
//#endif
//#ifndef checkoption
//#define checkoption lua_checkoption
//#endif
//#ifndef io_noclose
//#define io_noclose lua_io_noclose
//#endif
//#ifndef db_getuservalue
//#define db_getuservalue lua_db_getuservalue
//#endif
//#ifndef luaS_createlngstrobj
//#define luaS_createlngstrobj lua_luaS_createlngstrobj
//#endif
//#ifndef lua_setmetatable
//#define lua_setmetatable lua_lua_setmetatable
//#endif
//#ifndef str_find_aux
//#define str_find_aux lua_str_find_aux
//#endif
//#ifndef statement
//#define statement lua_statement
//#endif
//#ifndef db_getregistry
//#define db_getregistry lua_db_getregistry
//#endif
//#ifndef localfunc
//#define localfunc lua_localfunc
//#endif
//#ifndef math_sin
//#define math_sin lua_math_sin
//#endif
//#ifndef traverseLclosure
//#define traverseLclosure lua_traverseLclosure
//#endif
//#ifndef luaB_loadfile
//#define luaB_loadfile lua_luaB_loadfile
//#endif
//#ifndef propagatemark
//#define propagatemark lua_propagatemark
//#endif
//#ifndef lua_atpanic
//#define lua_atpanic lua_lua_atpanic
//#endif
//#ifndef DumpInteger
//#define DumpInteger lua_DumpInteger
//#endif
//#ifndef luaL_newstate
//#define luaL_newstate lua_luaL_newstate
//#endif
//#ifndef luaO_arith
//#define luaO_arith lua_luaO_arith
//#endif
//#ifndef getnum
//#define getnum lua_getnum
//#endif
//#ifndef closegoto
//#define closegoto lua_closegoto
//#endif
//#ifndef cond
//#define cond lua_cond
//#endif
//#ifndef lua_pushvfstring
//#define lua_pushvfstring lua_lua_pushvfstring
//#endif
//#ifndef match_capture
//#define match_capture lua_match_capture
//#endif
//#ifndef lua_getlocal
//#define lua_getlocal lua_lua_getlocal
//#endif
//#ifndef getbinopr
//#define getbinopr lua_getbinopr
//#endif
//#ifndef unbound_search
//#define unbound_search lua_unbound_search
//#endif
//#ifndef luaD_inctop
//#define luaD_inctop lua_luaD_inctop
//#endif
//#ifndef panic
//#define panic lua_panic
//#endif
//#ifndef luaE_extendCI
//#define luaE_extendCI lua_luaE_extendCI
//#endif
//#ifndef ll_loadlib
//#define ll_loadlib lua_ll_loadlib
//#endif
//#ifndef luaZ_init
//#define luaZ_init lua_luaZ_init
//#endif
//#ifndef pushfuncname
//#define pushfuncname lua_pushfuncname
//#endif
//#ifndef searcher_Lua
//#define searcher_Lua lua_searcher_Lua
//#endif
//#ifndef luaH_getshortstr
//#define luaH_getshortstr lua_luaH_getshortstr
//#endif
//#ifndef lua_compare
//#define lua_compare lua_lua_compare
//#endif
//#ifndef luaK_exp2val
//#define luaK_exp2val lua_luaK_exp2val
//#endif
//#ifndef str_sub
//#define str_sub lua_str_sub
//#endif
//#ifndef ll_searchpath
//#define ll_searchpath lua_ll_searchpath
//#endif
//#ifndef luaV_objlen
//#define luaV_objlen lua_luaV_objlen
//#endif
//#ifndef luaopen_bit32
//#define luaopen_bit32 lua_luaopen_bit32
//#endif
//#ifndef semerror
//#define semerror lua_semerror
//#endif
//#ifndef luaopen_table
//#define luaopen_table lua_luaopen_table
//#endif
//#ifndef b_str2int
//#define b_str2int lua_b_str2int
//#endif
//#ifndef auxresume
//#define auxresume lua_auxresume
//#endif
//#ifndef luaL_checkversion_
//#define luaL_checkversion_ lua_luaL_checkversion_
//#endif
//#ifndef generic_reader
//#define generic_reader lua_generic_reader
//#endif
//#ifndef luaB_rawset
//#define luaB_rawset lua_luaB_rawset
//#endif
//#ifndef lua_getallocf
//#define lua_getallocf lua_lua_getallocf
//#endif
//#ifndef luaL_checktype
//#define luaL_checktype lua_luaL_checktype
//#endif
//#ifndef esccheck
//#define esccheck lua_esccheck
//#endif
//#ifndef interror
//#define interror lua_interror
//#endif
//#ifndef moveresults
//#define moveresults lua_moveresults
//#endif
//#ifndef luaO_hexavalue
//#define luaO_hexavalue lua_luaO_hexavalue
//#endif
//#ifndef luaO_str2num
//#define luaO_str2num lua_luaO_str2num
//#endif
//#ifndef singlevaraux
//#define singlevaraux lua_singlevaraux
//#endif
//#ifndef rehash
//#define rehash lua_rehash
//#endif
//#ifndef markmt
//#define markmt lua_markmt
//#endif
//#ifndef check
//#define check lua_check
//#endif
//#ifndef lua_tointegerx
//#define lua_tointegerx lua_lua_tointegerx
//#endif
//#ifndef io_write
//#define io_write lua_io_write
//#endif
//#ifndef getupvalname
//#define getupvalname lua_getupvalname
//#endif
//#ifndef luaG_concaterror
//#define luaG_concaterror lua_luaG_concaterror
//#endif
//#ifndef swapextra
//#define swapextra lua_swapextra
//#endif
//#ifndef lua_newuserdata
//#define lua_newuserdata lua_lua_newuserdata
//#endif
//#ifndef error_expected
//#define error_expected lua_error_expected
//#endif
//#ifndef discharge2anyreg
//#define discharge2anyreg lua_discharge2anyreg
//#endif
//#ifndef io_popen
//#define io_popen lua_io_popen
//#endif
//#ifndef luaK_posfix
//#define luaK_posfix lua_luaK_posfix
//#endif
//#ifndef luaH_free
//#define luaH_free lua_luaH_free
//#endif
//#ifndef singlematch
//#define singlematch lua_singlematch
//#endif
//#ifndef io_close
//#define io_close lua_io_close
//#endif
//#ifndef findfile
//#define findfile lua_findfile
//#endif
//#ifndef restartcollection
//#define restartcollection lua_restartcollection
//#endif
//#ifndef pack
//#define pack lua_pack
//#endif
//#ifndef math_rad
//#define math_rad lua_math_rad
//#endif
//#ifndef utflen
//#define utflen lua_utflen
//#endif
//#ifndef errfile
//#define errfile lua_errfile
//#endif
//#ifndef luaL_addstring
//#define luaL_addstring lua_luaL_addstring
//#endif
//#ifndef checkSizes
//#define checkSizes lua_checkSizes
//#endif
//#ifndef luaC_freeallobjects
//#define luaC_freeallobjects lua_luaC_freeallobjects
//#endif
//#ifndef funcinfo
//#define funcinfo lua_funcinfo
//#endif
//#ifndef lua_rawgetp
//#define lua_rawgetp lua_lua_rawgetp
//#endif
//#ifndef isneg
//#define isneg lua_isneg
//#endif
//#ifndef lua_rawsetp
//#define lua_rawsetp lua_lua_rawsetp
//#endif
//#ifndef lua_gc
//#define lua_gc lua_lua_gc
//#endif
//#ifndef luaB_assert
//#define luaB_assert lua_luaB_assert
//#endif
//#ifndef LoadCode
//#define LoadCode lua_LoadCode
//#endif
//#ifndef enterblock
//#define enterblock lua_enterblock
//#endif
//#ifndef luaV_finishget
//#define luaV_finishget lua_luaV_finishget
//#endif
//#ifndef f_write
//#define f_write lua_f_write
//#endif
//#ifndef checktab
//#define checktab lua_checktab
//#endif
//#ifndef check_conflict
//#define check_conflict lua_check_conflict
//#endif
//#ifndef LEnum
//#define LEnum lua_LEnum
//#endif
//#ifndef choosePivot
//#define choosePivot lua_choosePivot
//#endif
//#ifndef math_tan
//#define math_tan lua_math_tan
//#endif
//#ifndef LoadBlock
//#define LoadBlock lua_LoadBlock
//#endif
//#ifndef searcher_C
//#define searcher_C lua_searcher_C
//#endif
//#ifndef luaopen_package
//#define luaopen_package lua_luaopen_package
//#endif
//#ifndef luaL_tolstring
//#define luaL_tolstring lua_luaL_tolstring
//#endif
//#ifndef reallymarkobject
//#define reallymarkobject lua_reallymarkobject
//#endif
//#ifndef auxgetstr
//#define auxgetstr lua_auxgetstr
//#endif
//#ifndef luaL_prepbuffsize
//#define luaL_prepbuffsize lua_luaL_prepbuffsize
//#endif
//#ifndef DumpBlock
//#define DumpBlock lua_DumpBlock
//#endif
//#ifndef lua_pushfstring
//#define lua_pushfstring lua_lua_pushfstring
//#endif
//#ifndef removevars
//#define removevars lua_removevars
//#endif
//#ifndef luaK_goiftrue
//#define luaK_goiftrue lua_luaK_goiftrue
//#endif
//#ifndef luaB_corunning
//#define luaB_corunning lua_luaB_corunning
//#endif
//#ifndef luaK_code
//#define luaK_code lua_luaK_code
//#endif
//#ifndef lua_pushlstring
//#define lua_pushlstring lua_lua_pushlstring
//#endif
//#ifndef DumpInt
//#define DumpInt lua_DumpInt
//#endif
//#ifndef patchtestreg
//#define patchtestreg lua_patchtestreg
//#endif
//#ifndef findlocal
//#define findlocal lua_findlocal
//#endif
//#ifndef patchlistaux
//#define patchlistaux lua_patchlistaux
//#endif
//#ifndef luaH_newkey
//#define luaH_newkey lua_luaH_newkey
//#endif
//#ifndef markupval
//#define markupval lua_markupval
//#endif
//#ifndef lua_topointer
//#define lua_topointer lua_lua_topointer
//#endif
//#ifndef auxupvalue
//#define auxupvalue lua_auxupvalue
//#endif
//#ifndef luaX_newstring
//#define luaX_newstring lua_luaX_newstring
//#endif
//#ifndef db_getinfo
//#define db_getinfo lua_db_getinfo
//#endif
//#ifndef math_deg
//#define math_deg lua_math_deg
//#endif
//#ifndef g_iofile
//#define g_iofile lua_g_iofile
//#endif
//#ifndef lsys_load
//#define lsys_load lua_lsys_load
//#endif
//#ifndef createmeta
//#define createmeta lua_createmeta
//#endif
//#ifndef freeexp
//#define freeexp lua_freeexp
//#endif
//#ifndef str_char
//#define str_char lua_str_char
//#endif
//#ifndef noenv
//#define noenv lua_noenv
//#endif
//#ifndef lua_pushlightuserdata
//#define lua_pushlightuserdata lua_lua_pushlightuserdata
//#endif
//#ifndef pushclosure
//#define pushclosure lua_pushclosure
//#endif
//#ifndef hookf
//#define hookf lua_hookf
//#endif
//#ifndef pairsmeta
//#define pairsmeta lua_pairsmeta
//#endif
//#ifndef addfield
//#define addfield lua_addfield
//#endif
//#ifndef io_output
//#define io_output lua_io_output
//#endif
//#ifndef code_loadbool
//#define code_loadbool lua_code_loadbool
//#endif
//#ifndef luaK_prefix
//#define luaK_prefix lua_luaK_prefix
//#endif
//#ifndef math_asin
//#define math_asin lua_math_asin
//#endif
//#ifndef os_time
//#define os_time lua_os_time
//#endif
//#ifndef math_fmod
//#define math_fmod lua_math_fmod
//#endif
//#ifndef io_tmpfile
//#define io_tmpfile lua_io_tmpfile
//#endif
//#ifndef seterrorobj
//#define seterrorobj lua_seterrorobj
//#endif
//#ifndef luaK_stringK
//#define luaK_stringK lua_luaK_stringK
//#endif
//#ifndef unpackint
//#define unpackint lua_unpackint
//#endif
//#ifndef luaK_indexed
//#define luaK_indexed lua_luaK_indexed
//#endif
//#ifndef unpack
//#define unpack lua_unpack
//#endif
//#ifndef luaH_new
//#define luaH_new lua_luaH_new
//#endif
//#ifndef makemask
//#define makemask lua_makemask
//#endif
//#ifndef lua_close
//#define lua_close lua_lua_close
//#endif
//#ifndef luaV_finishset
//#define luaV_finishset lua_luaV_finishset
//#endif
//#ifndef luaL_fileresult
//#define luaL_fileresult lua_luaL_fileresult
//#endif
//#ifndef fornum
//#define fornum lua_fornum
//#endif
//#ifndef freeexps
//#define freeexps lua_freeexps
//#endif
//#ifndef str_rep
//#define str_rep lua_str_rep
//#endif
//#ifndef luaZ_fill
//#define luaZ_fill lua_luaZ_fill
//#endif
//#ifndef checkfield
//#define checkfield lua_checkfield
//#endif
//#ifndef findgotos
//#define findgotos lua_findgotos
//#endif
//#ifndef traversetable
//#define traversetable lua_traversetable
//#endif
//#ifndef new_localvarliteral_
//#define new_localvarliteral_ lua_new_localvarliteral_
//#endif
//#ifndef push_onecapture
//#define push_onecapture lua_push_onecapture
//#endif
//#ifndef lua_rawlen
//#define lua_rawlen lua_lua_rawlen
//#endif
//#ifndef luaV_execute
//#define luaV_execute lua_luaV_execute
//#endif
//#ifndef getthread
//#define getthread lua_getthread
//#endif
//#ifndef luaS_clearcache
//#define luaS_clearcache lua_luaS_clearcache
//#endif
//#ifndef g_read
//#define g_read lua_g_read
//#endif
//#ifndef f_close
//#define f_close lua_f_close
//#endif
//#ifndef utf8esc
//#define utf8esc lua_utf8esc
//#endif
//#ifndef l_str2d
//#define l_str2d lua_l_str2d
//#endif
//#ifndef traverseweakvalue
//#define traverseweakvalue lua_traverseweakvalue
//#endif
//#ifndef undefgoto
//#define undefgoto lua_undefgoto
//#endif
//#ifndef readdigits
//#define readdigits lua_readdigits
//#endif
//#ifndef luaT_gettmbyobj
//#define luaT_gettmbyobj lua_luaT_gettmbyobj
//#endif
//#ifndef lua_rawset
//#define lua_rawset lua_lua_rawset
//#endif
//#ifndef luaK_codek
//#define luaK_codek lua_luaK_codek
//#endif
//#ifndef load_aux
//#define load_aux lua_load_aux
//#endif
//#ifndef luaopen_os
//#define luaopen_os lua_luaopen_os
//#endif
//#ifndef close_state
//#define close_state lua_close_state
//#endif
//#ifndef lua_arith
//#define lua_arith lua_lua_arith
//#endif
//#ifndef close_func
//#define close_func lua_close_func
//#endif
//#ifndef setfield
//#define setfield luaS_setfield
//#endif
//#ifndef LoadByte
//#define LoadByte lua_LoadByte
//#endif
//#ifndef luaK_codeABC
//#define luaK_codeABC lua_luaK_codeABC
//#endif
//#ifndef addliteral
//#define addliteral lua_addliteral
//#endif
//#ifndef min_expand
//#define min_expand lua_min_expand
//#endif
//#ifndef matchbalance
//#define matchbalance lua_matchbalance
//#endif
//#ifndef os_date
//#define os_date lua_os_date
//#endif
//#ifndef luaL_checkany
//#define luaL_checkany lua_luaL_checkany
//#endif
//#ifndef luaE_freethread
//#define luaE_freethread lua_luaE_freethread
//#endif
//#ifndef math_atan
//#define math_atan lua_math_atan
//#endif
//#ifndef lua_pushstring
//#define lua_pushstring lua_lua_pushstring
//#endif
//#ifndef LoadInt
//#define LoadInt lua_LoadInt
//#endif
//#ifndef matchbracketclass
//#define matchbracketclass lua_matchbracketclass
//#endif
//#ifndef luaS_eqlngstr
//#define luaS_eqlngstr lua_luaS_eqlngstr
//#endif
//#ifndef f_call
//#define f_call lua_f_call
//#endif
//#ifndef luaK_setlist
//#define luaK_setlist lua_luaK_setlist
//#endif
//#ifndef luaO_ceillog2
//#define luaO_ceillog2 lua_luaO_ceillog2
//#endif
//#ifndef traverseproto
//#define traverseproto lua_traverseproto
//#endif
//#ifndef luaV_lessthan
//#define luaV_lessthan lua_luaV_lessthan
//#endif
//#ifndef db_setuservalue
//#define db_setuservalue lua_db_setuservalue
//#endif
//#ifndef str_upper
//#define str_upper lua_str_upper
//#endif
//#ifndef LoadFunction
//#define LoadFunction lua_LoadFunction
//#endif
//#ifndef lua_upvaluejoin
//#define lua_upvaluejoin lua_lua_upvaluejoin
//#endif
//#ifndef luaK_ret
//#define luaK_ret lua_luaK_ret
//#endif
//#ifndef checkrepeated
//#define checkrepeated lua_checkrepeated
//#endif
//#ifndef setarrayvector
//#define setarrayvector lua_setarrayvector
//#endif
//#ifndef lua_getstack
//#define lua_getstack lua_lua_getstack
//#endif
//#ifndef luaK_numberK
//#define luaK_numberK lua_luaK_numberK
//#endif
//#ifndef check_match
//#define check_match lua_check_match
//#endif
//#ifndef luaK_codeABx
//#define luaK_codeABx lua_luaK_codeABx
//#endif
//#ifndef math_max
//#define math_max lua_math_max
//#endif
//#ifndef negatecondition
//#define negatecondition lua_negatecondition
//#endif
//#ifndef luaO_int2fb
//#define luaO_int2fb lua_luaO_int2fb
//#endif
//#ifndef setnodevector
//#define setnodevector lua_setnodevector
//#endif
//#ifndef luaC_step
//#define luaC_step lua_luaC_step
//#endif
//#ifndef partition
//#define partition lua_partition
//#endif
//#ifndef luaK_storevar
//#define luaK_storevar lua_luaK_storevar
//#endif
//#ifndef setboolfield
//#define setboolfield lua_setboolfield
//#endif
//#ifndef getdetails
//#define getdetails lua_getdetails
//#endif
//#ifndef lastlistfield
//#define lastlistfield lua_lastlistfield
//#endif
